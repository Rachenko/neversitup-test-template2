namespace neversitup_test_template_tests
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}