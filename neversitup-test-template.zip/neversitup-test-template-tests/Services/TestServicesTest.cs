using Azure.Core;
using Moq;
using neversitup_test_template.Helper;
using neversitup_test_template.Services;
using neversitup_test_template.Services.Interface;
using System.Collections.Generic;
using System.Security.Cryptography;

namespace neversitup_test_template_tests
{
    public class TestServicesTest
    {
        private readonly Mock<ITestServices> _addressService = new();

        [Theory]
        [InlineData("a")]
        [InlineData("ab")]
        [InlineData("abc")]
        [InlineData("aabb")]
        public async Task GetPermutationsAsync_ReturnPermutationData(string input)
        {
            #region Test Case
            var services = new TestServices(null);

            //Result
            var result = await services.GetPermutationsAsync(input);
            Assert.True(result.Any());

            string previous = string.Empty;
            List<string> permutations = new List<string>();
            foreach (var permu in result)
            {
                if (previous != permu)
                {
                    permutations.Add(permu);
                }
            }
            Assert.True(permutations.Count == result.Count);
            #endregion Test Case
        }

        [Theory]
        [InlineData("")]
        public async Task GetPermutationsAsync_ReturnInvalidFormat(string input)
        {
            #region Test Case
            var services = new TestServices( null);

            await Assert.ThrowsAsync<ArgumentException>(() => services.GetPermutationsAsync(input));
            #endregion Test Case
        }

        [Theory]
        [MemberData(nameof(FindTheOddIntData))]
        public async Task FindTheOddIntAsync_ReturnOddNumber(List<int> input)
        {
            #region Test Case
            var services = new TestServices(null);

            //Result
            var result = await services.FindTheOddIntAsync(input);
            Assert.True(input.Where(w => w == result).Count() % 2 != 0);

            #endregion Test Case
        }

        [Theory]
        [MemberData(nameof(FindTheOddIntError))]
        public async Task FindTheOddIntAsync_ReturnError(List<int> input)
        {
            #region Test Case
            var services = new TestServices(null);

            //Result
            await Assert.ThrowsAsync<ArgumentException>(() => services.FindTheOddIntAsync(input));

            #endregion Test Case
        }

        [Theory]
        [MemberData(nameof(CountSmileysAsyncData))]
        public async Task CountSmileysAsync_ReturnSmileyNumber(List<string> input)
        {
            #region Test Case
            var services = new TestServices(null);

            //Result
            var result = await services.CountSmileysAsync(input);
            Assert.True(result > 0);

            #endregion Test Case
        }

        [Theory]
        [MemberData(nameof(CountSmileysAsyncError))]
        public async Task CountSmileysAsync_ReturnZero(List<string> input)
        {
            #region Test Case
            var services = new TestServices(null);

            //Result
            var result = await services.CountSmileysAsync(input);
            Assert.True(result == 0);

            #endregion Test Case
        }

        public static IEnumerable<object[]> CountSmileysAsyncData()
        {
            yield return new object[] { new List<string> { ":)", ";(", ";}", ":-D" } };
            yield return new object[] { new List<string> { ";D", ":-(", ":-)", ";~)" } };
            yield return new object[] { new List<string> { ";]", ":[", ";*", ":$", ";-D" } };
        }

        public static IEnumerable<object[]> CountSmileysAsyncError()
        {
            yield return new object[] { new List<string> {} };

        }

        public static IEnumerable<object[]> FindTheOddIntData()
        {
            yield return new object[] { new List<int> { 7 } };
            yield return new object[] { new List<int> { 0 } };
            yield return new object[] { new List<int> { 1, 1, 2 } };
            yield return new object[] { new List<int> { 0, 1, 0, 1, 0 } };
            yield return new object[] { new List<int> { 1, 2, 2, 3, 3, 3, 4, 3, 3, 3, 2, 2, 1 } };
        }

        public static IEnumerable<object[]> FindTheOddIntError()
        {
            yield return new object[] { new List<int> { 1, 2, 2, 3, 3, 3, 4, 5, 3, 3, 3, 2, 2, 1 } };
        }
    }
}