﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace neversitup_test_template.Entities.ZortExam
{
    [Table("Product")]
    public class Product
    {
        [Key]
        public int ProductCode { get; set; }
        public string ProductName { get; set; }
    }
}
