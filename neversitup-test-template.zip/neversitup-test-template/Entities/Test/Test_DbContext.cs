﻿using Microsoft.EntityFrameworkCore;
using System.Reflection;

namespace neversitup_test_template.Entities.ZortExam
{
    public class Test_DbContext : DbContext
    {
        public Test_DbContext(DbContextOptions<Test_DbContext> options) : base(options) { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

        }

        public DbSet<Product> Product { get; set; }
    }

}
