using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;
using System.Net;
using neversitup_test_template.Models;
using neversitup_test_template.Models.Request;
using neversitup_test_template.Services.Interface;

namespace neversitup_test_template.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TestController : ControllerBase
    {
        private readonly ITestServices _testServices;

        public TestController(ITestServices testServices)
        {
            _testServices = testServices;
        }

        [HttpPost]
        [Route("Permutations")]
        [ProducesResponseType(typeof(PermutationsResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorResource), (int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> Permutations(PermutationsRequest request)
        {
            try
            {
                var result = await _testServices.GetPermutationsAsync(request.Input);
                var response = new PermutationsResponse(result);
                return Ok(response);
            }
            catch (Exception ex)
            {
                var errorInnerResources = JsonConvert.DeserializeObject<List<ErrorInnerResource>>(ex.Message);
                return BadRequest(new ErrorResource(errorInnerResources));
            }
        }

        [HttpPost]
        [Route("FindTheOddInt")]
        [ProducesResponseType(typeof(FindTheOddIntResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorResource), (int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> FindTheOddInt(List<int> request)
        {
            try
            {
                var result = await _testServices.FindTheOddIntAsync(request);
                var response = new FindTheOddIntResponse(result);
                return Ok(response);
            }
            catch (Exception ex)
            {
                var errorInnerResources = JsonConvert.DeserializeObject<List<ErrorInnerResource>>(ex.Message);
                return BadRequest(new ErrorResource(errorInnerResources));
            }
        }

        [HttpPost]
        [Route("CountSmileys")]
        [ProducesResponseType(typeof(CountSmileysResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorResource), (int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> CountSmileys(List<string> request)
        {
            try
            {
                var result = await _testServices.CountSmileysAsync(request);
                var response = new CountSmileysResponse(result);
                return Ok(response);
            }
            catch (Exception ex)
            {
                var errorInnerResources = JsonConvert.DeserializeObject<List<ErrorInnerResource>>(ex.Message);
                return BadRequest(new ErrorResource(errorInnerResources));
            }
        }
    }
}
