﻿using Newtonsoft.Json;

namespace neversitup_test_template.Models.Result
{
    public class PermutationsResult
    {
        public int ProductCode { get; set; }
        public string ProductName { get; set; }
        public decimal? TotalSales { get; set; }
    }
}