﻿using neversitup_test_template.Models.Result;

namespace neversitup_test_template.Models
{
    public class PermutationsResponse : BaseResponse<List<string>>
    {
        public PermutationsResponse(List<string> result) : base(result)
        { }

        public PermutationsResponse(string errorMessage) : base(errorMessage)
        { }
    }
}
