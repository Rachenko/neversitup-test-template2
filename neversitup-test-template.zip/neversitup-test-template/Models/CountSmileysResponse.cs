﻿using neversitup_test_template.Models.Result;

namespace neversitup_test_template.Models
{
    public class CountSmileysResponse : BaseResponse<int>
    {
        public CountSmileysResponse(int result) : base(result)
        { }

        public CountSmileysResponse(string errorMessage) : base(errorMessage)
        { }
    }
}
