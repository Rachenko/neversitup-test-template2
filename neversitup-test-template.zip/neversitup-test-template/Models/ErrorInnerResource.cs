﻿namespace neversitup_test_template.Models
{
    public class ErrorInnerResource
    {
        public int Code { get; set; }
        public string Message { get; set; }
    }
}
