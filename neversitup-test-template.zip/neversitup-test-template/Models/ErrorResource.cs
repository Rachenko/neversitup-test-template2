﻿namespace neversitup_test_template.Models
{
    public class ErrorResource
    {
        public bool Success => false;

        public Object Data { get; set; }
        public List<ErrorInnerResource> errors { get; private set; }

        public ErrorResource(List<ErrorInnerResource> errorLists)
        {
            Data = null;
            errors = errorLists;
        }
    }
}
