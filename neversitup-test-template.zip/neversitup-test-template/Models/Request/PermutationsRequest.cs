﻿namespace neversitup_test_template.Models.Request
{
    public class PermutationsRequest
    {
        public string Input { get; set; }
    }
}
