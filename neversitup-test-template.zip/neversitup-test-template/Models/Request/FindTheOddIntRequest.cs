﻿namespace neversitup_test_template.Models.Request
{
    public class FindTheOddIntRequest
    {
        public int Input { get; set; }
    }
}
