﻿using neversitup_test_template.Models.Result;

namespace neversitup_test_template.Models
{
    public class FindTheOddIntResponse : BaseResponse<int>
    {
        public FindTheOddIntResponse(int result) : base(result)
        { }

        public FindTheOddIntResponse(string errorMessage) : base(errorMessage)
        { }
    }
}
