
using neversitup_test_template.Helper.Interface;
using neversitup_test_template.Helper;
using neversitup_test_template.Services;
using neversitup_test_template.Services.Interface;
using neversitup_test_template.Entities.ZortExam;
using Microsoft.EntityFrameworkCore;
using neversitup_test_template.Repositories.Interface;
using neversitup_test_template.Repositories;
using Microsoft.AspNetCore.Mvc;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddHttpClient();
builder.Services.AddScoped<ITestServices, TestServices>();
builder.Services.AddScoped<ITestRepositories, TestRepositories>();
builder.Services.AddTransient<IAppSettingHelper, AppSettingHelper>();
builder.Services.AddDbContext<Test_DbContext>(options => options.UseSqlServer
(builder.Configuration.GetConnectionString("Test")));
builder.Services.AddControllers(options =>
{
    options.Filters.Add(new ProducesAttribute("application/json"));
});
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
