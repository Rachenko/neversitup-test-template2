﻿using neversitup_test_template.Entities.ZortExam;
using neversitup_test_template.Models.Result;

namespace neversitup_test_template.Repositories.Interface
{
    public interface ITestRepositories
    {
    }
}
