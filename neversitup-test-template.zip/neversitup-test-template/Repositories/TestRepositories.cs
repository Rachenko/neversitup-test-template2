﻿using Azure.Core;
using Microsoft.EntityFrameworkCore;
using neversitup_test_template.Models.Result;
using neversitup_test_template.Repositories.Interface;

namespace neversitup_test_template.Repositories
{
    public class TestRepositories : ITestRepositories
    {
      
    }
}
