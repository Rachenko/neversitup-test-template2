﻿using System.Threading.Tasks;
using neversitup_test_template.Models.Request;
using neversitup_test_template.Models.Result;

namespace neversitup_test_template.Services.Interface
{
    public interface ITestServices
    {
        public Task<List<string>> GetPermutationsAsync(string request);
        public Task<int> FindTheOddIntAsync(List<int> request);
        public Task<int> CountSmileysAsync(List<string> request);
    }
}
