﻿using Microsoft.OpenApi.Extensions;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Security.Cryptography;
using neversitup_test_template.Models;
using neversitup_test_template.Models.Request;
using neversitup_test_template.Models.Result;
using neversitup_test_template.Services.Interface;
using neversitup_test_template.Helper;
using Azure.Core;
using System.Linq;
using neversitup_test_template.Repositories.Interface;
using neversitup_test_template.Extension;
using System.Text.RegularExpressions;

namespace neversitup_test_template.Services
{
    public class TestServices : ITestServices
    {
        private readonly ITestRepositories _testRepositories;
        public TestServices(ITestRepositories testRepositories)
        {
            _testRepositories = testRepositories;
        }

        public async Task<List<string>> GetPermutationsAsync(string request)
        {
            try
            {
                if (string.IsNullOrEmpty(request) || request.Length == 0)
                {
                    ArgumentExceptionHelper.Throw(400, "Invalid request");
                }

                var result = new HashSet<string>();
                Permute(request.ToCharArray(), 0, result);
                var resultList = new List<string>(result);
                resultList.Sort();
                return resultList;
            }
            catch (ArgumentException arEx)
            {
                throw new ArgumentException(arEx.Message);
            }
            catch (Exception ex)
            {
                List<ErrorInnerResource> errorInnerResources = new List<ErrorInnerResource>();
                errorInnerResources.Add(new ErrorInnerResource { Code = 500, Message = ex.Message });
                string json = JsonConvert.SerializeObject(errorInnerResources);
                throw new Exception(json, ex);
            }
        }

        public async Task<int> FindTheOddIntAsync(List<int> request)
        {
            try
            {
                int result = 0;
                List<int> oddNumber = new List<int> { };
                foreach (int n in request)
                {
                    if (request.Where(w => w == n).Count() % 2 != 0 && !oddNumber.Any(w=>w == n))
                    {
                        oddNumber.Add(n);
                    }
                }

                if (oddNumber.Count > 1 && request.Where(w=>w == result).Count() % 2 == 0)
                {
                    ArgumentExceptionHelper.Throw(400, "Not Found one odd number");
                }

                result = oddNumber.FirstOrDefault();

                return result;
            }
            catch (ArgumentException arEx)
            {
                throw new ArgumentException(arEx.Message);
            }
            catch (Exception ex)
            {
                List<ErrorInnerResource> errorInnerResources = new List<ErrorInnerResource>();
                errorInnerResources.Add(new ErrorInnerResource { Code = 500, Message = ex.Message });
                string json = JsonConvert.SerializeObject(errorInnerResources);
                throw new Exception(json, ex);
            }
        }

        public async Task<int> CountSmileysAsync(List<string> request)
        {
            try
            {
                int result = 0;
                if (request.Any())
                {
                    foreach (var smiley in request)
                    {
                        if (IsValidSmiley(smiley))
                        {
                            result++;
                        }
                    }
                }
              
                return result;
            }
            catch (ArgumentException arEx)
            {
                throw new ArgumentException(arEx.Message);
            }
            catch (Exception ex)
            {
                List<ErrorInnerResource> errorInnerResources = new List<ErrorInnerResource>();
                errorInnerResources.Add(new ErrorInnerResource { Code = 500, Message = ex.Message });
                string json = JsonConvert.SerializeObject(errorInnerResources);
                throw new Exception(json, ex);
            }
        }

        private static bool IsValidSmiley(string smiley)
        {
            Regex regex = StringExtension.ValidSmileyFaceReg;
            return regex.IsMatch(smiley);
        }

        private void Permute(char[] arr, int start, HashSet<string> result)
        {
            if (start >= arr.Length)
            {
                result.Add(new string(arr));
                return;
            }

            for (int i = start; i < arr.Length; i++)
            {
                Swap(ref arr[start], ref arr[i]);
                Permute(arr, start + 1, result);
                Swap(ref arr[start], ref arr[i]);
            }
        }

        private void Swap(ref char a, ref char b)
        {
            if (a == b) return;
            char temp = a;
            a = b;
            b = temp;
        }
    }
}
