﻿namespace neversitup_test_template.Helper.Interface
{
    public interface IAppSettingHelper
    {
        string GetValue(string KeyPath);
        T GetValue<T>(string keyPath);
    }
}
