﻿using Newtonsoft.Json;
using neversitup_test_template.Models;

namespace neversitup_test_template.Helper
{
    public static class ArgumentExceptionHelper
    {
        public static void Throw(int code, string message)
        {
            List<ErrorInnerResource> errResource = new List<ErrorInnerResource>();
            errResource.Add(new ErrorInnerResource { Code = code, Message = message });
            string json = JsonConvert.SerializeObject(errResource);
            throw new ArgumentException(json);
        }

        public static void ErrorListThrow(List<ErrorInnerResource> errorList)
        {
            string json = JsonConvert.SerializeObject(errorList);
            throw new ArgumentException(json);
        }
    }
}
