﻿using System.Globalization;
using System.Text.RegularExpressions;

namespace neversitup_test_template.Extension
{
    public class StringExtension
    {
        public static Regex ValidSmileyFaceReg = new Regex(@"(:|;)(-|~)?(\)|D)");
    }
}
